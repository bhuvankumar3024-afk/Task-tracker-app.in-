'use strict';

const crypto = require('node:crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const BCRYPT_COST = 12;
const COOKIE_NAME = 'session';
const TOKEN_TTL = '7d';
const TOKEN_TTL_MS = 7 * 24 * 60 * 60 * 1000;

// JWT secret: use an explicit env var in production so sessions survive restarts
// and stay valid across multiple server instances. If none is set, generate a
// random one for this process only (fine for local/dev use).
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(48).toString('hex');
if (!process.env.JWT_SECRET) {
  console.warn(
    '[security] JWT_SECRET not set in environment - using a random per-process secret.\n' +
    '           All sessions will be invalidated on restart. Set JWT_SECRET in .env for production.'
  );
}

async function hashPassword(plain) {
  return bcrypt.hash(plain, BCRYPT_COST);
}

async function verifyPassword(plain, hash) {
  return bcrypt.compare(plain, hash);
}

function signSession(userId) {
  return jwt.sign({ sub: userId }, JWT_SECRET, { expiresIn: TOKEN_TTL });
}

function verifySession(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}

function cookieOptions() {
  return {
    httpOnly: true, // not readable from JS -> mitigates token theft via XSS
    secure: process.env.NODE_ENV === 'production', // requires HTTPS in production
    sameSite: 'strict', // browser won't attach this cookie to cross-site requests
    maxAge: TOKEN_TTL_MS,
    path: '/',
  };
}

function setSessionCookie(res, userId) {
  res.cookie(COOKIE_NAME, signSession(userId), cookieOptions());
}

function clearSessionCookie(res) {
  res.clearCookie(COOKIE_NAME, { ...cookieOptions(), maxAge: 0 });
}

// Requires a valid session cookie. Attaches req.userId.
function requireAuth(req, res, next) {
  const token = req.cookies && req.cookies[COOKIE_NAME];
  const payload = token && verifySession(token);
  if (!payload || !payload.sub) {
    return res.status(401).json({ error: 'Not authenticated.' });
  }
  req.userId = payload.sub;
  next();
}

// Lightweight CSRF defense-in-depth for state-changing requests.
// SameSite=Strict cookies already stop the browser from attaching the session
// cookie on cross-site requests. As a second layer, we also require a custom
// header that a plain cross-site <form> submission cannot set, while a normal
// same-origin fetch() call from our own frontend can.
function requireFetchHeader(req, res, next) {
  if (req.get('X-Requested-With') !== 'fetch') {
    return res.status(403).json({ error: 'Request rejected (missing required header).' });
  }
  next();
}

module.exports = {
  COOKIE_NAME,
  hashPassword,
  verifyPassword,
  setSessionCookie,
  clearSessionCookie,
  requireAuth,
  requireFetchHeader,
};
