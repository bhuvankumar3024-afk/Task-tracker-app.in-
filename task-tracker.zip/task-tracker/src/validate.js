'use strict';

const USERNAME_RE = /^[a-zA-Z0-9_-]{3,24}$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

function todayUTC() {
  return new Date().toISOString().slice(0, 10);
}

function isString(v) {
  return typeof v === 'string';
}

function username(v) {
  if (!isString(v) || !USERNAME_RE.test(v)) {
    return 'Username must be 3-24 characters: letters, numbers, underscore, or hyphen only.';
  }
  return null;
}

function password(v, opts = {}) {
  if (!isString(v) || v.length < 10 || v.length > 128) {
    return 'Password must be between 10 and 128 characters.';
  }
  if (opts.notEqualTo && v === opts.notEqualTo) {
    return 'Password cannot be the same as your username.';
  }
  return null;
}

function taskTitle(v) {
  if (!isString(v)) return 'Title is required.';
  const trimmed = v.trim();
  if (trimmed.length < 1 || trimmed.length > 200) {
    return 'Title must be between 1 and 200 characters.';
  }
  // Reject control characters (defense-in-depth; UI also renders via textContent only)
  // eslint-disable-next-line no-control-regex
  if (/[\x00-\x08\x0B\x0C\x0E-\x1F]/.test(trimmed)) {
    return 'Title contains invalid characters.';
  }
  return null;
}

function difficulty(v) {
  if (!['easy', 'medium', 'hard'].includes(v)) {
    return 'Difficulty must be easy, medium, or hard.';
  }
  return null;
}

function moodValue(v) {
  if (!Number.isInteger(v) || v < 1 || v > 5) {
    return 'Mood must be a whole number from 1 to 5.';
  }
  return null;
}

function noteText(v) {
  if (v === undefined || v === null || v === '') return null;
  if (!isString(v) || v.length > 500) return 'Note must be 500 characters or fewer.';
  return null;
}

function sleepHours(v) {
  if (typeof v !== 'number' || Number.isNaN(v) || v < 0 || v > 24) {
    return 'Sleep hours must be a number between 0 and 24.';
  }
  return null;
}

function sleepQuality(v) {
  if (!Number.isInteger(v) || v < 1 || v > 5) {
    return 'Sleep quality must be a whole number from 1 to 5.';
  }
  return null;
}

function dateStr(v) {
  if (!isString(v) || !DATE_RE.test(v)) return 'Date must be in YYYY-MM-DD format.';
  const d = new Date(v + 'T00:00:00Z');
  if (Number.isNaN(d.getTime())) return 'Date is not valid.';
  if (v > todayUTC()) return 'Date cannot be in the future.';
  const oneYearAgo = new Date();
  oneYearAgo.setUTCFullYear(oneYearAgo.getUTCFullYear() - 1);
  if (v < oneYearAgo.toISOString().slice(0, 10)) return 'Date is too far in the past.';
  return null;
}

module.exports = {
  todayUTC,
  username,
  password,
  taskTitle,
  difficulty,
  moodValue,
  noteText,
  sleepHours,
  sleepQuality,
  dateStr,
};
