'use strict';

const XP_BY_DIFFICULTY = { easy: 10, medium: 20, hard: 35 };
const XP_PER_LEVEL = 100;

function xpForDifficulty(difficulty) {
  return XP_BY_DIFFICULTY[difficulty] || 0;
}

function levelInfo(totalXp) {
  const xp = Math.max(0, totalXp);
  const level = Math.floor(xp / XP_PER_LEVEL) + 1;
  const xpIntoLevel = xp % XP_PER_LEVEL;
  return { level, xp, xpIntoLevel, xpForNextLevel: XP_PER_LEVEL };
}

function yesterday(dateStr) {
  const d = new Date(dateStr + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() - 1);
  return d.toISOString().slice(0, 10);
}

// Advances a user's streak at most once per calendar day, the first time they
// complete a task that day. Returns the new streak value.
function bumpStreak(user, todayStr) {
  if (user.last_active_date === todayStr) {
    return user.streak; // already counted today
  }
  if (user.last_active_date === yesterday(todayStr)) {
    return user.streak + 1;
  }
  return 1; // streak broken (or first ever activity)
}

module.exports = { xpForDifficulty, levelInfo, bumpStreak };
