'use strict';

const express = require('express');
const db = require('../db');
const v = require('../validate');
const { requireAuth, requireFetchHeader } = require('../auth');
const { xpForDifficulty, bumpStreak } = require('../gamify');

const router = express.Router();
router.use(requireAuth);

router.get('/', (req, res) => {
  const tasks = db
    .prepare('SELECT id, title, difficulty, completed, created_at, completed_at FROM tasks WHERE user_id = ? ORDER BY completed ASC, created_at DESC')
    .all(req.userId);
  res.json(tasks);
});

router.post('/', requireFetchHeader, (req, res) => {
  const { title, difficulty } = req.body || {};

  const tErr = v.taskTitle(title);
  if (tErr) return res.status(400).json({ error: tErr });

  const dErr = v.difficulty(difficulty);
  if (dErr) return res.status(400).json({ error: dErr });

  const info = db
    .prepare('INSERT INTO tasks (user_id, title, difficulty) VALUES (?, ?, ?)')
    .run(req.userId, title.trim(), difficulty);

  const task = db.prepare('SELECT id, title, difficulty, completed, created_at, completed_at FROM tasks WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json(task);
});

router.patch('/:id', requireFetchHeader, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: 'Invalid task id.' });

  const task = db.prepare('SELECT * FROM tasks WHERE id = ? AND user_id = ?').get(id, req.userId);
  if (!task) return res.status(404).json({ error: 'Task not found.' });

  const { completed } = req.body || {};
  if (typeof completed !== 'boolean') {
    return res.status(400).json({ error: '"completed" must be true or false.' });
  }

  const today = v.todayUTC();

  if (completed && !task.completed) {
    // Newly completed: award XP and roll the streak forward.
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.userId);
    const newStreak = bumpStreak(user, today);
    const xpGain = xpForDifficulty(task.difficulty);

    db.prepare('UPDATE tasks SET completed = 1, completed_at = ? WHERE id = ?').run(
      new Date().toISOString(),
      id
    );
    db.prepare('UPDATE users SET xp = xp + ?, streak = ?, last_active_date = ? WHERE id = ?').run(
      xpGain,
      newStreak,
      today,
      req.userId
    );
  } else if (!completed && task.completed) {
    // Reverted: remove the XP that was awarded. Streak/last-active is left as-is
    // by design, to keep the mental model simple ("streak" tracks days you showed
    // up, not a running total you can game by toggling tasks).
    const xpLoss = xpForDifficulty(task.difficulty);
    db.prepare('UPDATE tasks SET completed = 0, completed_at = NULL WHERE id = ?').run(id);
    db.prepare('UPDATE users SET xp = MAX(0, xp - ?) WHERE id = ?').run(xpLoss, req.userId);
  }

  const updated = db.prepare('SELECT id, title, difficulty, completed, created_at, completed_at FROM tasks WHERE id = ?').get(id);
  res.json(updated);
});

router.delete('/:id', requireFetchHeader, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: 'Invalid task id.' });

  const result = db.prepare('DELETE FROM tasks WHERE id = ? AND user_id = ?').run(id, req.userId);
  if (result.changes === 0) return res.status(404).json({ error: 'Task not found.' });
  res.status(204).end();
});

module.exports = router;
