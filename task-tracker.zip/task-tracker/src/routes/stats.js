'use strict';

const express = require('express');
const db = require('../db');
const v = require('../validate');
const { requireAuth } = require('../auth');
const { levelInfo } = require('../gamify');

const router = express.Router();
router.use(requireAuth);

router.get('/', (req, res) => {
  const user = db.prepare('SELECT xp, streak FROM users WHERE id = ?').get(req.userId);
  const today = v.todayUTC();

  const todayTasksTotal = db
    .prepare('SELECT COUNT(*) AS n FROM tasks WHERE user_id = ? AND date(created_at) = ?')
    .get(req.userId, today).n;
  const todayTasksDone = db
    .prepare("SELECT COUNT(*) AS n FROM tasks WHERE user_id = ? AND completed = 1 AND date(completed_at) = ?")
    .get(req.userId, today).n;
  const moodToday = db
    .prepare('SELECT mood FROM mood_logs WHERE user_id = ? AND date = ?')
    .get(req.userId, today);
  const sleepToday = db
    .prepare('SELECT hours, quality FROM sleep_logs WHERE user_id = ? AND date = ?')
    .get(req.userId, today);

  res.json({
    ...levelInfo(user.xp),
    streak: user.streak,
    today: {
      date: today,
      tasksTotal: todayTasksTotal,
      tasksDone: todayTasksDone,
      moodLogged: !!moodToday,
      mood: moodToday ? moodToday.mood : null,
      sleepLogged: !!sleepToday,
      sleep: sleepToday || null,
    },
  });
});

module.exports = router;
