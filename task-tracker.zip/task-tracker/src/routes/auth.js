'use strict';

const express = require('express');
const rateLimit = require('express-rate-limit');
const db = require('../db');
const v = require('../validate');
const {
  hashPassword,
  verifyPassword,
  setSessionCookie,
  clearSessionCookie,
  requireAuth,
  requireFetchHeader,
} = require('../auth');

const router = express.Router();

// Strict limiter on auth endpoints to slow down credential stuffing / brute force,
// on top of the per-account lockout below.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts. Try again later.' },
});

const LOCKOUT_THRESHOLD = 8;
const LOCKOUT_MINUTES = 15;

router.post('/register', authLimiter, requireFetchHeader, async (req, res) => {
  const { username, password } = req.body || {};

  const uErr = v.username(username);
  if (uErr) return res.status(400).json({ error: uErr });

  const pErr = v.password(password, { notEqualTo: username });
  if (pErr) return res.status(400).json({ error: pErr });

  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (existing) {
    // Same message shape as "invalid credentials" elsewhere avoids leaking too much,
    // but for registration we do need to tell the user the name is taken.
    return res.status(409).json({ error: 'That username is already taken.' });
  }

  const hash = await hashPassword(password);
  const info = db
    .prepare('INSERT INTO users (username, password_hash) VALUES (?, ?)')
    .run(username, hash);

  setSessionCookie(res, info.lastInsertRowid);
  res.status(201).json({ id: info.lastInsertRowid, username });
});

router.post('/login', authLimiter, requireFetchHeader, async (req, res) => {
  const { username, password } = req.body || {};
  if (typeof username !== 'string' || typeof password !== 'string') {
    return res.status(400).json({ error: 'Invalid credentials.' });
  }

  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);

  // Generic error message for both "no such user" and "wrong password" so an
  // attacker can't use this endpoint to enumerate valid usernames.
  const genericError = () => res.status(401).json({ error: 'Invalid username or password.' });

  if (!user) {
    // Still do a dummy hash compare so response timing doesn't reveal that the
    // username doesn't exist.
    await verifyPassword(password, '$2a$12$C6UzMDM.H6dfI/f/IKcEeO7hL5DGtYVoJ4G8mF8ZTfCH1QhKZ4jNa');
    return genericError();
  }

  if (user.locked_until && user.locked_until > new Date().toISOString()) {
    return res.status(423).json({ error: 'Account temporarily locked. Try again later.' });
  }

  const ok = await verifyPassword(password, user.password_hash);
  if (!ok) {
    const attempts = user.failed_attempts + 1;
    let lockedUntil = null;
    if (attempts >= LOCKOUT_THRESHOLD) {
      lockedUntil = new Date(Date.now() + LOCKOUT_MINUTES * 60 * 1000).toISOString();
    }
    db.prepare('UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?').run(
      attempts,
      lockedUntil,
      user.id
    );
    return genericError();
  }

  db.prepare('UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?').run(user.id);
  setSessionCookie(res, user.id);
  res.json({ id: user.id, username: user.username });
});

router.post('/logout', requireFetchHeader, (req, res) => {
  clearSessionCookie(res);
  res.json({ ok: true });
});

router.get('/me', requireAuth, (req, res) => {
  const user = db
    .prepare('SELECT id, username, created_at FROM users WHERE id = ?')
    .get(req.userId);
  if (!user) return res.status(401).json({ error: 'Not authenticated.' });
  res.json(user);
});

module.exports = router;
