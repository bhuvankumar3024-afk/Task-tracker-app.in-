'use strict';

const express = require('express');
const db = require('../db');
const v = require('../validate');
const { requireAuth, requireFetchHeader } = require('../auth');

const router = express.Router();
router.use(requireAuth);

router.get('/', (req, res) => {
  const days = Math.min(Math.max(Number(req.query.days) || 30, 1), 365);
  const rows = db
    .prepare('SELECT date, mood, note FROM mood_logs WHERE user_id = ? ORDER BY date DESC LIMIT ?')
    .all(req.userId, days);
  res.json(rows);
});

router.put('/', requireFetchHeader, (req, res) => {
  const { date, mood, note } = req.body || {};

  const dErr = v.dateStr(date);
  if (dErr) return res.status(400).json({ error: dErr });

  const mErr = v.moodValue(mood);
  if (mErr) return res.status(400).json({ error: mErr });

  const nErr = v.noteText(note);
  if (nErr) return res.status(400).json({ error: nErr });

  db.prepare(
    `INSERT INTO mood_logs (user_id, date, mood, note) VALUES (?, ?, ?, ?)
     ON CONFLICT(user_id, date) DO UPDATE SET mood = excluded.mood, note = excluded.note`
  ).run(req.userId, date, mood, note || null);

  const row = db.prepare('SELECT date, mood, note FROM mood_logs WHERE user_id = ? AND date = ?').get(req.userId, date);
  res.json(row);
});

module.exports = router;
