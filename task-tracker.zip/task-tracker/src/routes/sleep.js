'use strict';

const express = require('express');
const db = require('../db');
const v = require('../validate');
const { requireAuth, requireFetchHeader } = require('../auth');

const router = express.Router();
router.use(requireAuth);

router.get('/', (req, res) => {
  const days = Math.min(Math.max(Number(req.query.days) || 30, 1), 365);
  const rows = db
    .prepare('SELECT date, hours, quality FROM sleep_logs WHERE user_id = ? ORDER BY date DESC LIMIT ?')
    .all(req.userId, days);
  res.json(rows);
});

router.put('/', requireFetchHeader, (req, res) => {
  const { date, hours, quality } = req.body || {};

  const dErr = v.dateStr(date);
  if (dErr) return res.status(400).json({ error: dErr });

  const hErr = v.sleepHours(hours);
  if (hErr) return res.status(400).json({ error: hErr });

  const qErr = v.sleepQuality(quality);
  if (qErr) return res.status(400).json({ error: qErr });

  db.prepare(
    `INSERT INTO sleep_logs (user_id, date, hours, quality) VALUES (?, ?, ?, ?)
     ON CONFLICT(user_id, date) DO UPDATE SET hours = excluded.hours, quality = excluded.quality`
  ).run(req.userId, date, hours, quality);

  const row = db.prepare('SELECT date, hours, quality FROM sleep_logs WHERE user_id = ? AND date = ?').get(req.userId, date);
  res.json(row);
});

module.exports = router;
