'use strict';

require('dotenv').config();

const path = require('node:path');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');

const authRoutes = require('./src/routes/auth');
const taskRoutes = require('./src/routes/tasks');
const moodRoutes = require('./src/routes/mood');
const sleepRoutes = require('./src/routes/sleep');
const statsRoutes = require('./src/routes/stats');

const app = express();
const PORT = process.env.PORT || 3000;

// If deployed behind a reverse proxy / load balancer, this makes
// express-rate-limit and req.ip see the real client IP instead of the proxy's.
if (process.env.TRUST_PROXY === '1') {
  app.set('trust proxy', 1);
}

// --- Security headers -------------------------------------------------
// Strict CSP works because the frontend has zero inline <script>/<style> and
// never uses innerHTML with untrusted data (see public/app.js).
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'"],
        imgSrc: ["'self'", 'data:'],
        connectSrc: ["'self'"],
        objectSrc: ["'none'"],
        baseUri: ["'none'"],
        frameAncestors: ["'none'"],
        upgradeInsecureRequests: process.env.NODE_ENV === 'production' ? [] : null,
      },
    },
    crossOriginEmbedderPolicy: false,
  })
);

// --- Body parsing -------------------------------------------------------
app.use(express.json({ limit: '10kb' })); // small cap: this API never needs large payloads
app.use(cookieParser());

// --- General rate limiting (defense-in-depth beyond the stricter auth limiter) ---
app.use(
  '/api',
  rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 300,
    standardHeaders: true,
    legacyHeaders: false,
  })
);

// --- API routes -----------------------------------------------------------
app.use('/api/auth', authRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/mood', moodRoutes);
app.use('/api/sleep', sleepRoutes);
app.use('/api/stats', statsRoutes);

// --- Frontend (served by the same server/process as the API) --------------
app.use(
  express.static(path.join(__dirname, 'public'), {
    index: 'index.html',
    setHeaders: (res) => res.setHeader('X-Content-Type-Options', 'nosniff'),
  })
);

// --- 404 for unmatched API routes -----------------------------------------
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));

// --- Central error handler (never leak stack traces to the client) --------
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err && err.type === 'entity.too.large') {
    return res.status(413).json({ error: 'Request body too large.' });
  }
  if (err && err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'Malformed JSON body.' });
  }
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Something went wrong on our end.' });
});

app.listen(PORT, () => {
  console.log(`Task Game Tracker running at http://localhost:${PORT}`);
});
