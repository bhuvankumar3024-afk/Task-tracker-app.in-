# Task Game Tracker

A small, self-contained daily routine tracker: log tasks, mood, and sleep, earn
XP, level up, and keep a streak going. One Node.js process serves **both**
the JSON API and the frontend — there's no separate backend/frontend
deployment to keep in sync.

## Why it's built this way

- **Zero third-party runtime services.** SQLite lives inside the process via
  Node's built-in `node:sqlite` — no database server, no ORM, no native
  module to compile.
- **No external network calls from the browser.** No CDN scripts, no web
  fonts, no analytics. Everything the page needs ships in `public/`, which
  also lets the Content-Security-Policy below be genuinely strict instead of
  full of exceptions.
- **Small, readable dependency list.** `express`, `bcryptjs` (pure JS, no
  native build), `jsonwebtoken`, `helmet`, `express-rate-limit`,
  `cookie-parser`, `dotenv`. That's it.

## Run it

```bash
npm install
cp .env.example .env
# open .env and set JWT_SECRET to a long random string, e.g.:
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
npm start
```

Then open `http://localhost:3000`.

For local development with auto-restart on file changes: `npm run dev`.

## What's secured, and how

**Passwords**
- Hashed with bcrypt (cost factor 12), never stored or logged in plain text.
- Minimum length of 10 characters is enforced instead of forced complexity
  rules (arbitrary "must contain a symbol" rules push people toward
  predictable substitutions; length is the stronger signal).
- Login failures return the same generic "Invalid username or password"
  message whether the username exists or not, and a dummy hash comparison
  runs even when the account doesn't exist, so response timing doesn't leak
  which usernames are registered.
- After 8 failed attempts an account is locked for 15 minutes.

**Sessions**
- A signed JWT is stored in an `httpOnly` cookie, so it's invisible to
  JavaScript running on the page — a stray XSS bug can't read it and exfiltrate
  it.
- `sameSite: 'strict'` means the browser won't attach the cookie to any
  cross-site request in the first place, which is the primary defense against
  CSRF here.
- `secure` is turned on automatically when `NODE_ENV=production`, requiring
  HTTPS.
- As defense-in-depth, every state-changing request (`POST`/`PATCH`/`DELETE`)
  must also carry a custom `X-Requested-With: fetch` header. A plain HTML
  form submitted from another site can't set that header, so even a same-site
  navigation quirk wouldn't let an attacker trigger a mutation.

**Data access**
- Every query goes through parameterized statements (`node:sqlite` prepared
  statements) — user input is never concatenated into SQL.
- Every task/mood/sleep query is scoped to `WHERE user_id = ?` using the ID
  from the verified session, not from anything the client sends. Requesting
  or deleting another user's data returns a plain 404, not a permissions
  error that would confirm the record exists.

**Output / XSS**
- The frontend never uses `innerHTML` with server data — every dynamic value
  is written with `textContent`, so even a title like `<script>...</script>`
  (which the API happily stores verbatim, since mangling user data on the way
  in isn't the API's job) just renders as inert text.
- A strict Content-Security-Policy (`script-src 'self'`, no inline scripts or
  styles anywhere in the app) is a second layer in case that first one ever
  slips.

**Transport / general hardening**
- `helmet` sets the standard security headers (CSP, `X-Content-Type-Options`,
  `X-Frame-Options`, HSTS, etc).
- Request bodies are capped at 10 KB — this API never needs more.
- Two layers of rate limiting: a stricter one on `/api/auth/*` (20 requests /
  15 min) to slow credential stuffing, and a looser general one on `/api/*`
  (300 / 15 min).
- Errors are logged server-side but never sent to the client with a stack
  trace — the client only ever sees a generic message.

## What's deliberately left out (and what to do instead)

This is a self-contained demo, not a production deployment:

- **TLS/HTTPS**: terminate it in front of this app (nginx, Caddy, or your
  host's load balancer) and set `NODE_ENV=production` so cookies require it.
- **Horizontal scaling / multi-instance**: SQLite is single-file and fine for
  one process. For multiple instances behind a load balancer, swap `src/db.js`
  for Postgres/MySQL — the rest of the app (routes, validation, auth) doesn't
  need to change, since all SQL access is already isolated in one place.
- **Email verification / password reset**: not implemented; there's no email
  sending in this build.

## Project layout

```
server.js              # app wiring: security middleware, routes, error handler
src/db.js               # schema + connection (node:sqlite)
src/auth.js              # password hashing, JWT session cookies, auth middleware
src/validate.js          # input validation
src/gamify.js            # XP / level / streak rules
src/routes/               # auth, tasks, mood, sleep, stats
public/                  # frontend: index.html, style.css, app.js
```
