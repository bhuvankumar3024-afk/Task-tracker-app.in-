'use strict';

// ---- tiny fetch wrapper -----------------------------------------------
async function api(path, { method = 'GET', body } = {}) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (method !== 'GET') headers['X-Requested-With'] = 'fetch';

  const res = await fetch(path, {
    method,
    headers,
    credentials: 'same-origin',
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  if (res.status === 204) return null;

  let data = null;
  try {
    data = await res.json();
  } catch {
    /* no body */
  }

  if (!res.ok) {
    throw new Error((data && data.error) || `Request failed (${res.status})`);
  }
  return data;
}

// ---- view switching ------------------------------------------------------
const authView = document.getElementById('authView');
const appView = document.getElementById('appView');

function showAuth() {
  authView.hidden = false;
  appView.hidden = true;
}
function showApp() {
  authView.hidden = true;
  appView.hidden = false;
}

// ---- auth view -----------------------------------------------------------
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const authError = document.getElementById('authError');
const authTabs = document.querySelectorAll('.auth-tab');

authTabs.forEach((tab) => {
  tab.addEventListener('click', () => {
    authTabs.forEach((t) => {
      t.classList.toggle('is-active', t === tab);
      t.setAttribute('aria-selected', String(t === tab));
    });
    const isLogin = tab.dataset.tab === 'login';
    loginForm.hidden = !isLogin;
    registerForm.hidden = isLogin;
    hideAuthError();
  });
});

function showAuthError(message) {
  authError.textContent = message;
  authError.hidden = false;
}
function hideAuthError() {
  authError.hidden = true;
  authError.textContent = '';
}

loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  hideAuthError();
  const fd = new FormData(loginForm);
  try {
    await api('/api/auth/login', {
      method: 'POST',
      body: { username: fd.get('username'), password: fd.get('password') },
    });
    await bootApp();
  } catch (err) {
    showAuthError(err.message);
  }
});

registerForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  hideAuthError();
  const fd = new FormData(registerForm);
  try {
    await api('/api/auth/register', {
      method: 'POST',
      body: { username: fd.get('username'), password: fd.get('password') },
    });
    await bootApp();
  } catch (err) {
    showAuthError(err.message);
  }
});

document.getElementById('logoutBtn').addEventListener('click', async () => {
  try {
    await api('/api/auth/logout', { method: 'POST' });
  } catch {
    /* ignore */
  }
  showAuth();
});

// ---- app view: tasks -------------------------------------------------
const taskForm = document.getElementById('taskForm');
const taskList = document.getElementById('taskList');
const taskEmpty = document.getElementById('taskEmpty');

function renderTasks(tasks) {
  taskList.replaceChildren();
  taskEmpty.hidden = tasks.length > 0;

  for (const task of tasks) {
    const li = document.createElement('li');
    li.className = 'task-item' + (task.completed ? ' is-complete' : '');

    const check = document.createElement('button');
    check.type = 'button';
    check.className = 'task-check';
    check.setAttribute('aria-label', task.completed ? 'Mark incomplete' : 'Mark complete');
    check.addEventListener('click', () => toggleTask(task.id, !task.completed));

    const title = document.createElement('span');
    title.className = 'task-title';
    title.textContent = task.title; // textContent only: never rendered as HTML

    const diff = document.createElement('span');
    diff.className = 'task-diff';
    diff.textContent = task.difficulty;

    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'btn-icon';
    del.setAttribute('aria-label', 'Delete task');
    del.textContent = '×';
    del.addEventListener('click', () => deleteTask(task.id));

    li.append(check, title, diff, del);
    taskList.appendChild(li);
  }
}

async function loadTasks() {
  const tasks = await api('/api/tasks');
  renderTasks(tasks);
}

taskForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(taskForm);
  const title = String(fd.get('title') || '').trim();
  if (!title) return;
  await api('/api/tasks', { method: 'POST', body: { title, difficulty: fd.get('difficulty') } });
  taskForm.reset();
  await Promise.all([loadTasks(), loadStats()]);
});

async function toggleTask(id, completed) {
  await api(`/api/tasks/${id}`, { method: 'PATCH', body: { completed } });
  await Promise.all([loadTasks(), loadStats()]);
}

async function deleteTask(id) {
  await api(`/api/tasks/${id}`, { method: 'DELETE' });
  await Promise.all([loadTasks(), loadStats()]);
}

// ---- app view: mood -------------------------------------------------
const moodForm = document.getElementById('moodForm');
const moodScale = document.getElementById('moodScale');
const moodHistory = document.getElementById('moodHistory');
let selectedMood = null;

moodScale.addEventListener('click', (e) => {
  const btn = e.target.closest('.scale-btn');
  if (!btn) return;
  selectedMood = Number(btn.dataset.value);
  moodScale.querySelectorAll('.scale-btn').forEach((b) => b.classList.toggle('is-selected', b === btn));
});

moodForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!selectedMood) return;
  const fd = new FormData(moodForm);
  const today = new Date().toISOString().slice(0, 10);
  await api('/api/mood', {
    method: 'PUT',
    body: { date: today, mood: selectedMood, note: String(fd.get('note') || '').trim() || undefined },
  });
  await Promise.all([loadMoodHistory(), loadStats()]);
});

function renderMoodHistory(rows) {
  moodHistory.replaceChildren();
  const faces = { 1: '😞', 2: '🙁', 3: '😐', 4: '🙂', 5: '😄' };
  for (const row of rows.slice(0, 5)) {
    const li = document.createElement('li');
    const left = document.createElement('span');
    left.textContent = row.date;
    const right = document.createElement('span');
    right.textContent = faces[row.mood] || row.mood;
    li.append(left, right);
    moodHistory.appendChild(li);
  }
}

async function loadMoodHistory() {
  const rows = await api('/api/mood?days=14');
  renderMoodHistory(rows);
}

// ---- app view: sleep -------------------------------------------------
const sleepForm = document.getElementById('sleepForm');
const sleepScale = document.getElementById('sleepScale');
const sleepHistory = document.getElementById('sleepHistory');
let selectedSleepQuality = null;

sleepScale.addEventListener('click', (e) => {
  const btn = e.target.closest('.scale-btn');
  if (!btn) return;
  selectedSleepQuality = Number(btn.dataset.value);
  sleepScale.querySelectorAll('.scale-btn').forEach((b) => b.classList.toggle('is-selected', b === btn));
});

sleepForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!selectedSleepQuality) return;
  const fd = new FormData(sleepForm);
  const hours = Number(fd.get('hours'));
  const today = new Date().toISOString().slice(0, 10);
  await api('/api/sleep', {
    method: 'PUT',
    body: { date: today, hours, quality: selectedSleepQuality },
  });
  await Promise.all([loadSleepHistory(), loadStats()]);
});

function renderSleepHistory(rows) {
  sleepHistory.replaceChildren();
  for (const row of rows.slice(0, 5)) {
    const li = document.createElement('li');
    const left = document.createElement('span');
    left.textContent = row.date;
    const right = document.createElement('span');
    right.textContent = `${row.hours}h · Q${row.quality}`;
    li.append(left, right);
    sleepHistory.appendChild(li);
  }
}

async function loadSleepHistory() {
  const rows = await api('/api/sleep?days=14');
  renderSleepHistory(rows);
}

// ---- app view: stats / level / day arc --------------------------------
const levelBadge = document.getElementById('levelBadge');
const streakPill = document.getElementById('streakPill');
const xpFill = document.getElementById('xpFill');
const xpCaption = document.getElementById('xpCaption');
const arcTasks = document.getElementById('arcTasks');
const arcMood = document.getElementById('arcMood');
const arcSleep = document.getElementById('arcSleep');

function setArcSegment(el, ratio) {
  const pct = Math.max(0, Math.min(1, ratio)) * 100;
  el.setAttribute('stroke-dasharray', `${pct} ${100 - pct}`);
}

async function loadStats() {
  const stats = await api('/api/stats');
  levelBadge.textContent = `Lv ${stats.level}`;
  streakPill.textContent = `🔥 ${stats.streak}`;
  xpFill.style.width = `${(stats.xpIntoLevel / stats.xpForNextLevel) * 100}%`;
  xpCaption.textContent = `${stats.xpIntoLevel} / ${stats.xpForNextLevel} XP`;

  const taskRatio = stats.today.tasksTotal > 0 ? stats.today.tasksDone / stats.today.tasksTotal : 0;
  setArcSegment(arcTasks, taskRatio);
  setArcSegment(arcMood, stats.today.moodLogged ? 1 : 0);
  setArcSegment(arcSleep, stats.today.sleepLogged ? 1 : 0);
}

// ---- boot -----------------------------------------------------------
const userLabel = document.getElementById('userLabel');

async function bootApp() {
  try {
    const me = await api('/api/auth/me');
    userLabel.textContent = me.username;
    showApp();
    await Promise.all([loadTasks(), loadMoodHistory(), loadSleepHistory(), loadStats()]);
  } catch {
    showAuth();
  }
}

bootApp();
